const timeAndDate = require("./timeAndDate.js");

timeAndDate.timeAndDate();
