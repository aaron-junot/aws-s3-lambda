exports.timeAndDate = () => {
  callback(null, "Success");
}
